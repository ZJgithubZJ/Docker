cd /app && mkdir -p wygkk && cd wygkk

wget -O 2.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/11/28/S9DRKG6QF_sd.flv"
wget -O 3.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/11/28/S9DRKJQ6T_sd.flv"
wget -O 4.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/12/16/S9F9SGNJ0_sd.flv"
wget -O 5.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/12/16/S9F9SK021_sd.flv"
wget -O 6.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/12/27/S9G6BI70O_sd.flv"
wget -O 7.flv "http://mov.bn.netease.com/open-movie/nos/flv/2013/12/27/S9G6BM0D5_sd.flv"
wget -O 8.flv "http://mov.bn.netease.com/open-movie/nos/flv/2014/01/14/S9HKQ3RFK_sd.flv"
wget -O 9.flv "http://mov.bn.netease.com/open-movie/nos/flv/2014/01/15/S9HNB90OH_sd.flv"
wget -O 10.flv "http://mov.bn.netease.com/open-movie/nos/flv/2014/02/17/S9KCDA65O_sd.flv"

sz -be 2.flv 
sz -be 3.flv 
sz -be 4.flv 
sz -be 5.flv 
sz -be 6.flv 
sz -be 7.flv 
sz -be 8.flv 
sz -be 9.flv 
sz -be 10.flv 
